<?php

$lang['googlesearch']['search'] = 'Szukaj';
$lang['googlesearch']['search in google'] = 'Szukaj w Google..';

?>